"""
peek.py  —  bas raw text dikhata hai, kuch banata/badalta nahi.
Rakh: DataBase/ folder me (DC.PY ke bagal me). Chala: python peek.py
Output: terminal pe print + _peek_dump.txt file me save.
Mujhe yeh _peek_dump.txt bhej de -> main parser tere exact layout pe set kar dunga.
"""
import os, pdfplumber

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
YEAR_DIR   = os.path.join(SCRIPT_DIR, "2024")
OUT        = os.path.join(SCRIPT_DIR, "_peek_dump.txt")

with open(OUT, "w", encoding="utf-8") as fh:
    for fname in sorted(os.listdir(YEAR_DIR)):
        if not fname.lower().endswith(".pdf"):
            continue
        path = os.path.join(YEAR_DIR, fname)
        header = f"\n########## {fname} ##########\n"
        print(header); fh.write(header)
        with pdfplumber.open(path) as pdf:
            # sirf pehli 2 pages ka text — layout samajhne ke liye kaafi hai
            for pno, page in enumerate(pdf.pages[:2], 1):
                txt = page.extract_text(x_tolerance=2, y_tolerance=2) or ""
                lines = txt.split("\n")[:45]   # har page se max 45 lines
                block = f"\n----- page {pno} (pehli 45 lines) -----\n" + "\n".join(lines) + "\n"
                print(block); fh.write(block)

print(f"\n\n>>> Saved to: {OUT}  —  yeh file mujhe bhej de.")
