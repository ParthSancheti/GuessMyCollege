"""
================================================================================
 make_2024_pune_mumbai_excel.py
================================================================================
 Reads the 2024 "Maharashtra & Minority Seats" CAP cutoff PDFs (the ones with
 the GOPENS/GSCS/... category grid), keeps only PUNE + MUMBAI colleges, with
 ALL categories, and writes a clean Excel.

 Put this file in:  DataBase/   (next to DC.PY)
   DataBase/
   ├── make_2024_pune_mumbai_excel.py   <- THIS FILE
   └── 2024/
       ├── 2024ENGG_CAP1_CutOff.pdf     \
       ├── 2024ENGG_CAP2_CutOff.pdf      }  <- these 3 are USED (category grid)
       └── 2024ENGG_CAP3_CutOff.pdf     /
       (… _AI_CutOff.pdf, _Diploma.pdf, SeatMatrix.pdf are AUTO-SKIPPED:
         different layout, no category grid.)

 Run:
   cd DataBase
   python make_2024_pune_mumbai_excel.py

 3 stages:
   STAGE 1: extract all colleges/categories  -> all_2024_raw.csv
   STAGE 2: filter Pune + Mumbai             -> (in memory, logs matched insts)
   STAGE 3: write Excel                       -> 2024_Pune_Mumbai_Cutoffs.xlsx

 First run tip: set DEBUG_DUMP=True to also write _debug_raw_2024.txt.
================================================================================
"""

import os
import re
import csv
import logging
import pdfplumber
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

# ==========================================================================
# CONFIG
# ==========================================================================
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
YEAR_DIR   = os.path.join(SCRIPT_DIR, "2024")
RAW_CSV    = os.path.join(SCRIPT_DIR, "all_2024_raw.csv")
EXCEL_OUT  = os.path.join(SCRIPT_DIR, "2024_Pune_Mumbai_Cutoffs.xlsx")
DEBUG_TXT  = os.path.join(SCRIPT_DIR, "_debug_raw_2024.txt")
DEBUG_DUMP = False

# Keep a college if its Institute Name contains ANY keyword (lowercase).
PUNE_KEYWORDS   = ["pune", "pimpri", "chinchwad", "lonavala", "talegaon",
                   "lavale", "wagholi", "akurdi", "nigdi", "ravet"]
MUMBAI_KEYWORDS = ["mumbai", "navi mumbai", "thane", "panvel", "kalyan",
                   "dombivli", "vasai", "virar", "bhiwandi", "ulhasnagar",
                   "badlapur", "ambernath", "kharghar", "airoli", "powai",
                   "andheri", "bandra", "kurla", "nerul", "belapur", "kamothe",
                   "vile parle", "borivali", "malad", "kandivali", "chembur",
                   "sion", "wadala", "versova", "ghansoli", "koparkhairane"]

# ==========================================================================
# REGEX (tuned to the real 2024 PDFs)
# ==========================================================================
RE_INSTITUTE  = re.compile(r"^\s*(\d{4,5})\s*-\s*(.+?)$")         # 01002 - College ...
RE_COURSE     = re.compile(r"^\s*(\d{9,10})\s*-\s*(.+?)$")        # 0100219110 - Course ...
RE_PERCENTILE = re.compile(r"\(?(100(?:\.0+)?|\d{1,2}\.\d+)\)?")  # (88.5013511)
RE_STAGE      = re.compile(r"^(I|II|III|IV|V|VI|VII|VIII|IX|X)$") # roman stage label
# Category / seat-type token: GOPENS, GSCS, LOPENS, PWDOPENS, DEFOBCS, TFWS, EWS, ORPHAN...
RE_SEAT_TYPE  = re.compile(r"^([GL][A-Z0-9]{2,8}|EWS|TFWS|ORPHAN|"
                           r"PWD[A-Z0-9]+|DEF[A-Z0-9]+|AI|MI)$")

# Canonical column order for the wide sheet (unknowns appended alphabetically).
CANON_ORDER = [
    "GOPENS","GOPENH","GOPENO","GSCS","GSCH","GSCO","GSTS","GSTH","GSTO",
    "GVJS","GVJH","GVJO","GNT1S","GNT2S","GNT3S","GOBCS","GOBCH","GOBCO","GSEBCS",
    "LOPENS","LOPENH","LOPENO","LSCS","LSTS","LVJS","LNT1S","LNT2S","LNT3S","LOBCS","LSEBCS",
    "PWDOPENS","PWDOBCS","PWDRSCS","PWDROBCS","PWDROBC",
    "DEFOPENS","DEFOBCS","DEFRSCS","DEFROBCS","DEFRSEBCS","DEFRSEBC","DEFRNT1S",
    "TFWS","EWS","ORPHAN","MI","AI",
]


# ==========================================================================
# STAGE 1 — EXTRACT
# ==========================================================================
def group_words_into_lines(words, y_tol=3):
    lines = []
    for w in sorted(words, key=lambda x: (round(x["top"]), x["x0"])):
        for ln in lines:
            if abs(ln["top"] - w["top"]) <= y_tol:
                ln["words"].append(w)
                break
        else:
            lines.append({"top": w["top"], "words": [w]})
    for ln in lines:
        ln["words"].sort(key=lambda x: x["x0"])
        ln["text"] = " ".join(x["text"] for x in ln["words"])
    lines.sort(key=lambda l: l["top"])
    return lines


def center(w):
    return (w["x0"] + w["x1"]) / 2.0


def map_to_columns(words, columns, skip_first_label=False):
    """Assign each data word to its nearest header column (by x-center).
       Blank cells handled naturally: a missing column simply gets no word."""
    out = {}
    ws = words[1:] if (skip_first_label and words) else list(words)
    centers = [c[0] for c in columns]
    if len(centers) >= 2:
        gaps = [centers[i+1] - centers[i] for i in range(len(centers)-1)]
        tol = max(10.0, 0.6 * min(gaps))
    else:
        tol = 40.0
    for w in ws:
        cx = center(w)
        best = min(columns, key=lambda c: abs(c[0] - cx))
        if abs(best[0] - cx) <= tol:
            out[best[1]] = w["text"]
    return out


def extract_pdf(pdf_path, round_num, debug_fh=None):
    records = []
    inst_code = inst_name = choice_code = course_name = None
    columns = None
    pending_stage = None
    pending_ranks = {}

    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            words = page.extract_words(x_tolerance=1.5, y_tolerance=1.5,
                                       keep_blank_chars=False)
            if not words:
                continue
            lines = group_words_into_lines(words)
            if debug_fh:
                debug_fh.write(f"\n----- {os.path.basename(pdf_path)} -----\n")
                for ln in lines:
                    debug_fh.write(ln["text"] + "\n")

            for ln in lines:
                text = ln["text"].strip()
                tokens = ln["words"]
                if not text:
                    continue

                # 1) Institute
                m = RE_INSTITUTE.match(text)
                if m and not RE_COURSE.match(text):
                    inst_code, inst_name = m.group(1), m.group(2).strip()
                    columns = None
                    pending_stage, pending_ranks = None, {}
                    continue

                # 2) Course / choice code
                m = RE_COURSE.match(text)
                if m:
                    choice_code, course_name = m.group(1), m.group(2).strip()
                    columns = None
                    pending_stage, pending_ranks = None, {}
                    continue

                # 3) Header (build column map)
                first = tokens[0]["text"]
                seat_tok = [w for w in tokens if RE_SEAT_TYPE.match(w["text"])]
                if (first.lower().startswith("stage") or
                        (choice_code and len(seat_tok) >= 3)) and seat_tok:
                    columns = [(center(w), w["text"]) for w in seat_tok]
                    pending_stage, pending_ranks = None, {}
                    continue

                if not (choice_code and columns):
                    continue

                # 4) Rank row (leading roman numeral)
                if RE_STAGE.match(first):
                    pending_stage = first
                    pending_ranks = map_to_columns(tokens, columns,
                                                   skip_first_label=True)
                    continue

                # 5) Percentile row — only valid right after a roman rank row
                if pending_stage and "(" in text and RE_PERCENTILE.search(text):
                    pct_map = map_to_columns(tokens, columns)
                    for seat, raw in pct_map.items():
                        pm = RE_PERCENTILE.search(raw)
                        if not pm:
                            continue
                        rank_raw = pending_ranks.get(seat, "")
                        rank = re.sub(r"\D", "", rank_raw) or None
                        records.append({
                            "institute_code": inst_code,
                            "institute_name": inst_name,
                            "choice_code":    choice_code,
                            "course_name":    course_name,
                            "round":          round_num,
                            "stage":          pending_stage,
                            "seat_type":      seat,
                            "rank":           rank,
                            "percentile":     float(pm.group(1)),
                        })
                    pending_stage, pending_ranks = None, {}
                    continue

    return records


def is_category_file(fname):
    low = fname.lower()
    if not (low.endswith(".pdf") and "cutoff" in low):
        return False
    if "_ai_" in low or "diploma" in low or "seatmatrix" in low:
        return False
    return True


def stage1_extract_all():
    if not os.path.isdir(YEAR_DIR):
        logging.error(f"Folder not found: {YEAR_DIR}")
        return []
    debug_fh = open(DEBUG_TXT, "w", encoding="utf-8") if DEBUG_DUMP else None
    all_records = []
    for fname in sorted(os.listdir(YEAR_DIR)):
        if not is_category_file(fname):
            if fname.lower().endswith(".pdf"):
                logging.info(f"STAGE 1: skipping {fname} (not a category-grid file)")
            continue
        rm = re.search(r"cap(\d)", fname.lower())
        round_num = int(rm.group(1)) if rm else 1
        logging.info(f"STAGE 1: extracting {fname} (CAP{round_num})")
        recs = extract_pdf(os.path.join(YEAR_DIR, fname), round_num, debug_fh)
        logging.info(f"         -> {len(recs)} rows")
        all_records.extend(recs)
    if debug_fh:
        debug_fh.close()
        logging.info(f"Debug raw text -> {DEBUG_TXT}")
    if all_records:
        with open(RAW_CSV, "w", newline="", encoding="utf-8") as f:
            w = csv.DictWriter(f, fieldnames=list(all_records[0].keys()))
            w.writeheader(); w.writerows(all_records)
        logging.info(f"STAGE 1 done: {len(all_records)} rows -> {RAW_CSV}")
    else:
        logging.warning("STAGE 1 = 0 rows. Set DEBUG_DUMP=True and check the dump.")
    return all_records


# ==========================================================================
# STAGE 2 — FILTER
# ==========================================================================
def region_of(name):
    n = (name or "").lower()
    if any(k in n for k in PUNE_KEYWORDS):
        return "Pune"
    if any(k in n for k in MUMBAI_KEYWORDS):
        return "Mumbai"
    return None


def stage2_filter(records):
    kept = []
    for r in records:
        reg = region_of(r["institute_name"])
        if reg:
            r = dict(r); r["region"] = reg
            kept.append(r)
    insts = sorted({(r["region"], r["institute_code"], r["institute_name"]) for r in kept})
    logging.info(f"STAGE 2 done: kept {len(kept)} rows across {len(insts)} institutes:")
    for reg, ic, iname in insts:
        logging.info(f"      [{reg}] {ic} - {iname}")
    return kept


# ==========================================================================
# closing cutoff per (college, course, round, category) = lowest percentile
# ==========================================================================
def aggregate_closing(records):
    best = {}
    for r in records:
        key = (r["region"], r["institute_code"], r["institute_name"],
               r["choice_code"], r["course_name"], r["round"], r["seat_type"])
        if key not in best or r["percentile"] < best[key]["percentile"]:
            best[key] = r
    return list(best.values())


# ==========================================================================
# STAGE 3 — EXCEL
# ==========================================================================
HDR_FILL = PatternFill("solid", fgColor="1F4E78")
HDR_FONT = Font(bold=True, color="FFFFFF", name="Calibri", size=10)
CELL_FONT = Font(name="Calibri", size=10)
THIN = Side(style="thin", color="D9D9D9")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
PUNE_FILL = PatternFill("solid", fgColor="E8F1FB")
MUMBAI_FILL = PatternFill("solid", fgColor="FBF0E8")


def seat_order_key(st):
    return (CANON_ORDER.index(st) if st in CANON_ORDER else len(CANON_ORDER), st)


def _style_header(ws, ncols):
    for c in range(1, ncols + 1):
        cell = ws.cell(row=1, column=c)
        cell.fill = HDR_FILL; cell.font = HDR_FONT
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cell.border = BORDER
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = f"A1:{get_column_letter(ncols)}1"


def stage3_write_excel(records):
    if not records:
        logging.warning("Nothing to write."); return
    closing = aggregate_closing(records)
    wb = Workbook()

    # ---- Sheet 1: LONG (one row per category, closing cutoff) ----
    ws1 = wb.active; ws1.title = "Cutoffs_Long"
    cols = ["Region","Institute_Code","Institute_Name","Choice_Code",
            "Course_Name","Round","Seat_Type","Rank","Percentile"]
    ws1.append(cols)
    for r in sorted(closing, key=lambda r: (r["region"], r["institute_name"],
                    r["course_name"], r["round"], seat_order_key(r["seat_type"]))):
        ws1.append([r["region"], r["institute_code"], r["institute_name"],
                    r["choice_code"], r["course_name"], r["round"], r["seat_type"],
                    int(r["rank"]) if r.get("rank") else None, r["percentile"]])
    for row in ws1.iter_rows(min_row=2, max_row=ws1.max_row):
        for c in row: c.font = CELL_FONT; c.border = BORDER
        row[0].fill = PUNE_FILL if row[0].value == "Pune" else MUMBAI_FILL
        row[8].number_format = "0.0000000"
    _style_header(ws1, len(cols))
    for i, w in enumerate([9,13,42,13,34,7,12,9,11], 1):
        ws1.column_dimensions[get_column_letter(i)].width = w

    # ---- Sheet 2: WIDE (categories as columns) ----
    seats = sorted({r["seat_type"] for r in closing}, key=seat_order_key)
    ws2 = wb.create_sheet("Cutoffs_Wide")
    wcols = ["Region","Institute_Code","Institute_Name","Choice_Code",
             "Course_Name","Round"] + seats
    ws2.append(wcols)
    grouped = {}
    for r in closing:
        key = (r["region"], r["institute_code"], r["institute_name"],
               r["choice_code"], r["course_name"], r["round"])
        grouped.setdefault(key, {})[r["seat_type"]] = r["percentile"]
    for key in sorted(grouped, key=lambda k: (k[0], k[2], k[4], k[5])):
        row = list(key) + [grouped[key].get(s) for s in seats]
        ws2.append(row)
    for row in ws2.iter_rows(min_row=2, max_row=ws2.max_row):
        for c in row: c.font = CELL_FONT; c.border = BORDER
        row[0].fill = PUNE_FILL if row[0].value == "Pune" else MUMBAI_FILL
        for c in row[6:]: c.number_format = "0.0000000"
    _style_header(ws2, len(wcols))
    for i, w in enumerate([9,13,42,13,34,7], 1):
        ws2.column_dimensions[get_column_letter(i)].width = w
    for i in range(7, len(wcols) + 1):
        ws2.column_dimensions[get_column_letter(i)].width = 11

    wb.save(EXCEL_OUT)
    logging.info(f"STAGE 3 done -> {EXCEL_OUT}")
    logging.info(f"   Long rows: {ws1.max_row-1} | Wide rows: {ws2.max_row-1} "
                 f"| categories: {len(seats)}")


def main():
    logging.info("==========  2024 Pune/Mumbai Cutoff Builder  ==========")
    raw = stage1_extract_all()
    kept = stage2_filter(raw)
    stage3_write_excel(kept)
    logging.info("Done.")


if __name__ == "__main__":
    main()
