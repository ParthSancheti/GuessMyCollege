import os
import re
import pdfplumber
import pandas as pd
import logging

logging.basicConfig(level=logging.INFO, format="%(levelname)s: %(message)s")

# ==========================================
# EXACT REGEX PATTERNS FROM DC.PY
# ==========================================
RE_INSTITUTE = re.compile(r"^\s*(\d{4})\s*-\s*(.+?)$")
RE_COURSE = re.compile(r"^\s*(\d{9})\s*-\s*(.+?)$")
RE_PERCENTILE = re.compile(r"\(?(100(?:\.0+)?|\d{1,2}\.\d+)\)?")
RE_SEAT_TYPE = re.compile(r"\b([GL][A-Z]{3,5}[HO]?|AI|DEF\d|PWD\d|EWS|TFWS)\b")

def extract_to_excel():
    SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
    
    # Safely find PDFs in the current folder or a '2024' subfolder
    search_dirs = [os.path.join(SCRIPT_DIR, "2024"), SCRIPT_DIR]
    pdf_paths = []
    
    for d in search_dirs:
        if os.path.exists(d):
            for f in os.listdir(d):
                low = f.lower()
                if low.endswith(".pdf") and "cutoff" in low:
                    pdf_paths.append(os.path.join(d, f))
    
    pdf_paths = list(set(pdf_paths)) # Remove duplicates

    if not pdf_paths:
        logging.error("No cutoff PDFs found.")
        return

    all_data = []

    for pdf_path in pdf_paths:
        filename = os.path.basename(pdf_path)
        round_match = re.search(r"CAP(\d)", filename, re.IGNORECASE)
        round_num = int(round_match.group(1)) if round_match else 1
        
        logging.info(f"Parsing: {filename} (Round {round_num})...")
        
        curr_inst_code = None
        curr_inst_name = None
        curr_choice_code = None
        curr_course_name = None

        with pdfplumber.open(pdf_path) as pdf:
            for page in pdf.pages:
                # EXACT PARSER FROM DC.PY
                text = page.extract_text(x_tolerance=2, y_tolerance=2)
                if not text:
                    continue

                lines = text.split('\n')
                for line in lines:
                    line = line.strip()
                    if not line:
                        continue

                    # 1. Detect Institute
                    inst_match = RE_INSTITUTE.match(line)
                    if inst_match:
                        curr_inst_code = inst_match.group(1).strip()
                        curr_inst_name = inst_match.group(2).strip()
                        curr_choice_code = None  # Reset course when college changes
                        continue

                    # 2. Detect Course
                    course_match = RE_COURSE.match(line)
                    if course_match:
                        curr_choice_code = course_match.group(1).strip()
                        curr_course_name = course_match.group(2).strip()
                        continue
                        
                    # 3. Detect Cutoffs
                    if curr_choice_code:
                        pct_match = RE_PERCENTILE.search(line)
                        seat_match = RE_SEAT_TYPE.search(line)

                        if pct_match:
                            percentile = float(pct_match.group(1))
                            seat_type = seat_match.group(1) if seat_match else "GOPEN"

                            all_data.append({
                                "Institute_Code": curr_inst_code,
                                "Institute_Name": curr_inst_name,
                                "Choice_Code": curr_choice_code,
                                "Course_Name": curr_course_name,
                                "Round": round_num,
                                "Seat_Type": seat_type,
                                "Percentile": percentile
                            })

    if not all_data:
        logging.error("Failed to extract data. Ensure PDFs are valid.")
        return

    # Load all extracted data into Pandas
    df = pd.DataFrame(all_data)
    
    # Apply DC.PY's duplicate removal logic
    df = df.drop_duplicates(subset=['Choice_Code', 'Round', 'Seat_Type'], keep='last')
    logging.info(f"Successfully extracted {len(df)} total cutoff rows.")

    # ==========================================
    # FILTER FOR MUMBAI AND PUNE HERE
    # ==========================================
    # We use case-insensitive string matching on the Institute Name
    df_filtered = df[df['Institute_Name'].str.contains('Mumbai|Pune', case=False, na=False)]
    
    logging.info(f"Filtered down to {len(df_filtered)} rows for Mumbai/Pune.")

    # Just in case the filter misses things, save it out
    output_file = "Mumbai_Pune_2024_Cutoffs.xlsx"
    output_path = os.path.join(SCRIPT_DIR, output_file)
    
    try:
        # Sort and save
        df_filtered = df_filtered.sort_values(by=["Institute_Name", "Course_Name", "Round", "Seat_Type"])
        df_filtered.to_excel(output_path, index=False, sheet_name="2024_Cutoffs")
        logging.info(f"🎉 SUCCESS! Saved {len(df_filtered)} rows to {output_file}")
    except Exception as e:
        logging.error(f"❌ Failed to save Excel file. Error: {e}")

if __name__ == "__main__":
    extract_to_excel()